jQuery(function(){
    jQuery('#btn-viewresult').click();
});
