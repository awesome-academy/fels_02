jQuery(function(){
    jQuery('#auto_load').click();
	jQuery('#btn-topic-today').click();
});
